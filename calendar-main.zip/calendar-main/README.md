# Calendar

Hello World! This is Elai Shane from ESTech Channel.

I have created a new series nammed **Calendar** in which I will be showing you multiple calendar UI and make connections with the firebase, SQLite, Google Calendar as well as physical devices.

I do hope you like the series.
If you like the code and the content. Do like, share my video and star my github repository. Also share my youtube channel which would motivate me to create more contents
 
